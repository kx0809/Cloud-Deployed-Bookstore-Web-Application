<style>
    /* Footer styles */
    footer {
            background-color: #1d1d1f;
            color: white;
            text-align: center;
            padding: 20px;
            margin-top: auto; /* Push the footer to the bottom */
        }

        footer p {
            margin: 0;
        }

</style>

<footer>
        <p>&copy; 2025 Unpopular. All rights reserved.</p>
</footer>