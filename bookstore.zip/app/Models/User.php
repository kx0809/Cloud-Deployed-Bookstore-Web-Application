<?php

namespace App\Models;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;

    protected $table = 'users'; // Define the table name explicitly
    protected $primaryKey = 'id'; // Define the primary key

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'name',
        'email',
        'password',
        'is_admin',
        'profile_image',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    /**
     * A user can have multiple purchased books.
     */
    public function purchasedBooks()
    {
        return $this->hasMany(PurchasedBook::class, 'user_id');
    }

    /**
     * A user can have multiple contact form submissions.
     */
    public function contactForms()
    {
        return $this->hasMany(ContactForm::class, 'user_id');
    }

    /**
     * A user can have multiple items in their shopping cart.
     */
    public function cartItems()
    {
        return $this->hasMany(ShoppingCart::class, 'user_id');
    }
}
